from django.shortcuts import render
 
# import view sets from the REST framework
from rest_framework import viewsets
 
# import the siemoptSerializer from the serializer file
from .serializers import siemoptSerializer
 
# import the siemopt model from the models file
from .models import siemopt,AlertSummaryData

from rest_framework.response import Response
from rest_framework.decorators import api_view

from django.http import JsonResponse
from .serializers import siemoptSerializer
# create a class for the siemopt model viewsets
class siemoptView(viewsets.ModelViewSet):
 
    # create a serializer class and
    # assign it to the siemoptSerializer class
    serializer_class = siemoptSerializer
 
    # define a variable and populate it
    # with the siemopt list objects
    queryset = siemopt.objects.all()

@api_view(['GET', 'POST'])
def getRoutes(request):
    
    routes = [
        {
            'Endpoint': '/notes/',
            'method': 'GET',
            'body': None,
            'description': 'Returns an array of notes'
        },
        {
            'Endpoint': '/notes/id',
            'method': 'GET',
            'body': None,
            'description': 'Returns a single note object'
        },
        {
            'Endpoint': '/notes/create/',
            'method': 'POST',
            'body': {'body': ""},
            'description': 'Creates new note with data sent in post request'
        },
        {
            'Endpoint': '/notes/id/update/',
            'method': 'PUT',
            'body': {'body': ""},
            'description': 'Creates an existing note with data sent in post request'
        },
        {
            'Endpoint': '/notes/id/delete/',
            'method': 'DELETE',
            'body': None,
            'description': 'Deletes and exiting note'
        },
    ]
    return Response(routes)   
 
@api_view(['GET'])
def getAsdata(request):
    asdata = AlertSummaryData.objects.all()
    serializer = siemoptSerializer(asdata, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def getOneAsdata(request, pk):
    asdata = AlertSummaryData.objects.get(id=pk)
    serializer = siemoptSerializer(asdata, many=False)
    return Response(serializer.data)    